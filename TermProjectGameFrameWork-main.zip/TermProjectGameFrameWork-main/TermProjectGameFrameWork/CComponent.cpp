#include "pch.h"
#include "CComponent.h"
