#include "pch.h"

#include "C:\Users\chlwo\OneDrive\Desktop\TermProjectGameFrameWork\CPlayer.cpp"


#include "C:\Users\chlwo\OneDrive\Desktop\TermProjectGameFrameWork\CRes.cpp"


#include "C:\Users\chlwo\OneDrive\Desktop\TermProjectGameFrameWork\CResMgr.cpp"

