#include "pch.h"

#include "C:\Users\jwogu\Documents\TermProjectGameFrameWork\TermProjectGameFrameWork\CComponent.cpp"


#include "C:\Users\jwogu\Documents\TermProjectGameFrameWork\TermProjectGameFrameWork\CCore.cpp"


#include "C:\Users\jwogu\Documents\TermProjectGameFrameWork\TermProjectGameFrameWork\CDebugMgr.cpp"

