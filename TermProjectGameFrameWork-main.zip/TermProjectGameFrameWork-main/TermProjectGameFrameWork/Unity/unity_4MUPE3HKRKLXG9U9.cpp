#include "pch.h"

#include "C:\Users\chlwo\OneDrive\Document\TermProjectGameFrameWork\TermProjectGameFrameWork\CPlayer.cpp"


#include "C:\Users\chlwo\OneDrive\Document\TermProjectGameFrameWork\TermProjectGameFrameWork\CRes.cpp"


#include "C:\Users\chlwo\OneDrive\Document\TermProjectGameFrameWork\TermProjectGameFrameWork\CResMgr.cpp"

